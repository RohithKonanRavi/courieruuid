# CourierUUID

CourierUUID is a Python library for generating UUIDs, tailored for courier services.

## Installation

Run the following to install:

``` bash
pip install courieruuid

from courieruuid.generator import generate_uuid

print(generate_uuid())



```