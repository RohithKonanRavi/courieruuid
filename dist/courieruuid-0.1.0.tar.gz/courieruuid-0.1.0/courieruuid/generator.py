import uuid

def generate_uuid():
    "Generate and return a new UUID."
    return uuid.uuid4()
